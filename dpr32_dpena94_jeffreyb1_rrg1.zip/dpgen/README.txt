Date: 11/2/2017
Assigment #2

1) Team 
	Devan Paul Roper 		dpr32		574A
	Dillon Jay Pena 		dpena94		574A
	Jefferey Burton			jeffreyb1	574A
	Reginal Raymond Glenn		rrg1		574A

2) Description
	The dpgen project is made to convert c like code into valid verilog modules.  The arguments for executing 
	the program are the executable, input parameter, output parameter.
		ex: dpgen input.txt output.txt
	
3) Contribution
	+ Devan Paul Roper
		Project Skeleton/Layout
		Bit Size
		Output File Layout
		Padding/Extension
		CMake setup
		Bug Fixes
		
	+ Dillon Jay Pena
		Project skeleton/layout
		Input, wire, register -> Verilog code
		All operations -> verilog modules
		Critical path estimation
		Bug Fixes
		
	+ Jefferey Burton
	-none
		
	+ Reginal Raymond Glenn
	-none
